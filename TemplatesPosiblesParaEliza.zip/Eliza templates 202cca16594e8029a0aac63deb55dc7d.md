# Eliza templates

Templates válidos 

1. ***Saludos normales :***
- hola mi nombre es s(_)
- buendia mi nombre es s(_)
- hola, mi nombre es s(_)
- buendia mi nombre es s(_)
- hola _
- buendia _
- hola soy s(_)
- hola me llamo s(_)
- buenos dias me llamo s(_)
- hey me llamo s(_)
- holi soy s(_)
- que tal, me llamo s(_)
- hola
- buenos dias
- buenas tardes
- buenas noches
- hola s(_), mucho gusto
- buenas s(_), soy s(_)

1. ***Preguntas simples***
- como te llamas?
- quien eres?
- cual es tu nombre?
- cuantos anios tienes?
- donde vives?
- como estas?
- como te sientes?
- estas bien?
- puedes ayudarme?
- que piensas de s(_)?

1. ***Preguntas especificas de gota (enfermedad)***
- hablame acerca de la s(_enfermedad,condicion,dolencia) gota
- que es la enfermedad gota?
- cuales son los sintomas de la gota?
- que causa la gota?
- como se trata la gota?
- tengo gota
- que alimentos debo evitar con gota?
- la gota es hereditaria?
- se puede curar la gota?
- que hacer durante un ataque de gota?
- que especialista trata la gota?
- me puedo morir de gota?

1. ***Preguntas especificas de la escoliosis***
- hablame de la escoliosis
- que es la escoliosis?
- como se si tengo escoliosis?
- la escoliosis duele?
- la escoliosis es grave?
- cual es la causa de la escoliosis?
- la escoliosis tiene cura?
- puedo hacer ejercicio con escoliosis?
- la escoliosis puede empeorar?
- la escoliosis afecta a adultos?
- la escoliosis es peligrosa?

1. ***Usando variables s(_) : casos posibles*** 

**GOTA**

### 1. `template([tengo, sintomas, como, s(_), y, s(_)], ...)`

**Casos posibles:**

- tengo sintomas como **dolor** y **hinchazon**
- tengo sintomas como **enrojecimiento** y **ardor**
- tengo sintomas como **fiebre** y **dolor**
- tengo sintomas como **rigidez** y **dolor**
- tengo sintomas como **dolor** y **calor**

---

### 2. `template([que, pasa, si, tengo, s(_), por, gota], ...)`

**Casos posibles:**

- que pasa si tengo **dolor** por gota
- que pasa si tengo **inflamacion** por gota
- que pasa si tengo **crisis** por gota
- que pasa si tengo **ataque** por gota
- que pasa si tengo **enrojecimiento** por gota

---

### 3. `template([puedo, tomar, s(_), si, tengo, gota], ...)`

**Casos posibles:**

- puedo tomar **ibuprofeno** si tengo gota
- puedo tomar **alcohol** si tengo gota
- puedo tomar **aspirina** si tengo gota
- puedo tomar **colchicina** si tengo gota
- puedo tomar **diureticos** si tengo gota

---

### **ESCOLIOSIS**

### 4. `template([tengo, dolor, en, s(_), puede, ser, escoliosis], ...)`

**Casos posibles:**

- tengo dolor en **espalda** puede ser escoliosis
- tengo dolor en **columna** puede ser escoliosis
- tengo dolor en **cintura** puede ser escoliosis
- tengo dolor en **hombro** puede ser escoliosis
- tengo dolor en **torso** puede ser escoliosis

---

### 5. `template([que, ejercicios, son, buenos, para, s(_), con, escoliosis], ...)`

**Casos posibles:**

- que ejercicios son buenos para **espalda** con escoliosis
- que ejercicios son buenos para **columna** con escoliosis
- que ejercicios son buenos para **zona lumbar** con escoliosis
- que ejercicios son buenos para **musculos** con escoliosis
- que ejercicios son buenos para **cintura** con escoliosis

---

### 6. `template([puedo, tener, escoliosis, si, s(_), esta, s(_)], ...)`

**Casos posibles:**

- puedo tener escoliosis si **la espalda** esta **torcida**
- puedo tener escoliosis si **la columna** esta **curvada**
- puedo tener escoliosis si **mi postura** esta **desalineada**
- puedo tener escoliosis si **mi torso** esta **inclinado**
- puedo tener escoliosis si **la pelvis** esta **desnivelada**

---

### 7. `template([la, escoliosis, empeora, con, s(_)], ...)`

**Casos posibles:**

- la escoliosis empeora con **mala postura**
- la escoliosis empeora con **cargas pesadas**
- la escoliosis empeora con **sedentarismo**
- la escoliosis empeora con **malos habitos**
- la escoliosis empeora con **falta de ejercicio**

1. ***Gustos de Eliza***
- te gustan los s(_)?
    
    ```perl
    likes(programacion).
    likes(tecnologia).
    likes(carros).
    likes(musica).
    likes(cafe).
    likes(libros).
    likes(animales).
    likes(caminatas).
    likes(computadoras).
    likes(lluvia).
    ```
    

1. ***Despedidas***
- chao
- nos vemos
- hasta luego
- bye
- bye eliza
- adios

1. ***Templates posibles para al arbol genealógico***

- ¿Quién es el papá de Leo?
- ¿Quién es la mamá de Ana?
- ¿Quiénes son los hermanos de Carlos?
- ¿Quién es el hermano de María?
- ¿Quiénes son los primos de Omar?
- ¿Quién es el tío de Lucia?
- ¿Quién es el abuelo de Juan?
- ¿Quién es la abuela de Sofía?
- ¿Quiénes son los hijos de Pedro?
- ¿Quién es el esposo de Laura?
- ¿Quién es la esposa de Andrés?
- ¿Quiénes son los nietos de Teresa?
- ¿Quién es el sobrino de Elena?
- ¿Quién es la sobrina de Marta?
- ¿Quiénes son los padres de Diego?
- ¿Quién es el cuñado de Jorge?
- ¿Quién es la cuñada de Carla?
- ¿Quiénes son los suegros de Pablo?
- ¿Quién es el yerno de Ana?
- ¿Quién es la nuera de Luis?